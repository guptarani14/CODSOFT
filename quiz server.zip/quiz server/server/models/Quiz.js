const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  questionText: {
    type: String,
    required: true,
  },
  options: [String],
  correctAnswer: {
    type: String,
    required: true,
  },
});

const quizSchema = new mongoose.Schema({
  title: String,
  description: String, // ✅ ADD THIS LINE
  questions: [questionSchema],
});


module.exports = mongoose.model("Quiz", quizSchema);
