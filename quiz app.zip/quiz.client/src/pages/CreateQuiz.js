import React, { useState } from "react";
import axios from "axios";

const CreateQuiz = () => {
  const [title, setTitle] = useState("");
  const [questions, setQuestions] = useState([
    { questionText: "", options: ["", "", "", ""], correctAnswer: "" },
  ]);

  const handleQuestionChange = (index, field, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index][field] = value;
    setQuestions(updatedQuestions);
  };

  const handleOptionChange = (qIndex, optIndex, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[qIndex].options[optIndex] = value;

    if (
      updatedQuestions[qIndex].correctAnswer ===
      updatedQuestions[qIndex].options[optIndex]
    ) {
      updatedQuestions[qIndex].correctAnswer = value;
    }

    setQuestions(updatedQuestions);
  };

  const handleCorrectAnswerChange = (qIndex, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[qIndex].correctAnswer =
      updatedQuestions[qIndex].options[Number(value)];
    setQuestions(updatedQuestions);
  };

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      { questionText: "", options: ["", "", "", ""], correctAnswer: "" },
    ]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("⚠️ Please login first to create a quiz.");
        return;
      }

      const formData = { title, questions };

      await axios.post("http://localhost:5000/api/quiz", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      alert("✅ Quiz Created Successfully!");
      setTitle("");
      setQuestions([
        { questionText: "", options: ["", "", "", ""], correctAnswer: "" },
      ]);
    } catch (err) {
      console.error("Error:", err);
      alert("❌ Error creating quiz");
    }
  };

  // 🌈 Updated Colorful Style
  const pageStyle = {
    background: "linear-gradient(135deg, #f3f0ff, #e0f7fa)",
    minHeight: "100vh",
    padding: "40px 20px",
    fontFamily: "Segoe UI, sans-serif",
  };

  const cardStyle = {
    background: "#ffffff",
    borderRadius: "12px",
    padding: "30px",
    maxWidth: "850px",
    margin: "0 auto",
    boxShadow: "0 0 25px rgba(0,0,0,0.1)",
  };

  const titleStyle = {
    color: "#311b92", // deep indigo
    fontSize: "30px",
    textAlign: "center",
    marginBottom: "30px",
    fontWeight: "700",
  };

  const inputStyle = {
    marginBottom: "14px",
    padding: "12px",
    border: "1px solid #ccc",
    borderRadius: "8px",
    fontSize: "16px",
    width: "100%",
    backgroundColor: "#fdfbff",
  };

  const selectStyle = {
    ...inputStyle,
    backgroundColor: "#eef7f0",
  };

  const buttonStyle = {
    padding: "12px 20px",
    borderRadius: "8px",
    border: "none",
    fontSize: "16px",
    fontWeight: "bold",
    marginRight: "12px",
    cursor: "pointer",
  };

  const addBtn = {
    ...buttonStyle,
    backgroundColor: "#00a896", // turquoise
    color: "#fff",
  };

  const submitBtn = {
    ...buttonStyle,
    backgroundColor: "#6a1b9a", // purple
    color: "#fff",
  };

  const questionBox = {
    background: "#ffffff",
    border: "2px solid #d1c4e9",
    borderRadius: "10px",
    padding: "20px",
    marginBottom: "30px",
    boxShadow: "0 2px 10px rgba(0,0,0,0.05)",
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h2 style={titleStyle}>🧠 Create a New Quiz</h2>
        <form onSubmit={handleSubmit}>
          <label><strong>📌 Quiz Title:</strong></label>
          <input
            type="text"
            style={inputStyle}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />

          {questions.map((q, qIndex) => (
            <div key={qIndex} style={questionBox}>
              <h4 style={{ color: "#1a237e", marginBottom: "10px" }}>
                📝 Question {qIndex + 1}
              </h4>
              <input
                type="text"
                style={inputStyle}
                placeholder="Enter your question here"
                value={q.questionText}
                onChange={(e) =>
                  handleQuestionChange(qIndex, "questionText", e.target.value)
                }
                required
              />

              {q.options.map((opt, optIndex) => (
                <div
                  key={optIndex}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    backgroundColor: "#f1f8e9",
                    borderRadius: "8px",
                    padding: "8px",
                    marginBottom: "8px",
                    border: "1px solid #c5e1a5",
                  }}
                >
                  <span style={{ marginRight: "10px", color: "#004d40" }}>
                    Option {optIndex + 1}:
                  </span>
                  <input
                    type="text"
                    style={{
                      flex: 1,
                      padding: "10px",
                      borderRadius: "6px",
                      border: "1px solid #a5d6a7",
                      backgroundColor: "#ffffff",
                    }}
                    placeholder={`Option ${optIndex + 1}`}
                    value={opt}
                    onChange={(e) =>
                      handleOptionChange(qIndex, optIndex, e.target.value)
                    }
                    required
                  />
                </div>
              ))}

              <label
                style={{
                  fontWeight: "bold",
                  marginTop: "10px",
                  color: "#1b5e20",
                }}
              >
                ✅ Select correct option:
              </label>
              <select
                style={selectStyle}
                value={q.options.indexOf(q.correctAnswer)}
                onChange={(e) =>
                  handleCorrectAnswerChange(qIndex, e.target.value)
                }
                required
              >
                <option value="">-- Select Correct Option --</option>
                {q.options.map((opt, i) => (
                  <option key={i} value={i}>
                    Option {i + 1}: {opt || `Option ${i + 1}`}
                  </option>
                ))}
              </select>
            </div>
          ))}

          <button type="button" style={addBtn} onClick={handleAddQuestion}>
            ➕ Add Question
          </button>
          <button type="submit" style={submitBtn}>
            🚀 Create Quiz
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateQuiz;
