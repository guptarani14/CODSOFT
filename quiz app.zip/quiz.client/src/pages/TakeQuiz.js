import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const TakeQuiz = () => {
  const { id } = useParams();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchQuiz = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/quiz/${id}`);
        setQuiz(res.data);
        setAnswers(new Array(res.data.questions.length).fill(''));
      } catch (err) {
        alert('Error fetching quiz');
      }
    };

    fetchQuiz();
  }, [id]);

  const handleChange = (index, value) => {
    const updated = [...answers];
    updated[index] = value;
    setAnswers(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`http://localhost:5000/api/quiz/submit/${id}`, {
        answers,
      });
      setScore(res.data.score);
      setSubmitted(true);
    } catch (err) {
      alert('Error submitting quiz');
    }
  };

  if (!quiz) return <div>Loading quiz...</div>;

  if (submitted) {
    return (
      <div className="container mt-4">
        <h2>{quiz.title}</h2>
        <div className="alert alert-success">
          ✅ Your Score: {score} / {quiz.questions.length}
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/')}>
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h2>{quiz.title}</h2>
      <form onSubmit={handleSubmit}>
        {quiz.questions.map((q, index) => (
          <div key={index} className="mb-4">
            <h5>Q{index + 1}. {q.questionText}</h5>
            {q.options.map((opt, i) => (
              <div className="form-check" key={i}>
                <input
                  className="form-check-input"
                  type="radio"
                  name={`q${index}`}
                  value={opt}
                  checked={answers[index] === opt}
                  onChange={() => handleChange(index, opt)}
                  required
                />
                <label className="form-check-label">{opt}</label>
              </div>
            ))}
          </div>
        ))}
        <button className="btn btn-success" type="submit">Submit Quiz</button>
      </form>
    </div>
  );
};

export default TakeQuiz;
