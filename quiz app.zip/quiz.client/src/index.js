import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
//  Remove this line if you don’t have this file:
// import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css'; // ✅ Bootstrap import

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Remove this line if you removed the import above:
// reportWebVitals();
