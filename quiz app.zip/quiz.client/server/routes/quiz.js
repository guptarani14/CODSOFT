const express = require("express");
const router = express.Router();
const Quiz = require("../models/Quiz");
const authMiddleware = require("../middleware/authMiddleware");

// 🔐 ✅ Protected POST /api/quiz - Create a quiz
router.post("/", authMiddleware, async (req, res) => {
  try {
    const { title, description, questions } = req.body;
    const newQuiz = new Quiz({ title, description, questions });
    await newQuiz.save();
    res.status(201).json(newQuiz);
  } catch (error) {
    console.error("❌ Error creating quiz:", error);
    res.status(500).json({ error: "Error creating quiz" });
  }
});

// ✅ PUT /api/quiz/:id - Update a quiz (Protected)
router.put("/:id", authMiddleware, async (req, res) => {
  try {
    const { title, description, questions } = req.body;

    const updatedQuiz = await Quiz.findByIdAndUpdate(
      req.params.id,
      { title, description, questions },
      { new: true } // return updated document
    );

    if (!updatedQuiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    res.json(updatedQuiz);
  } catch (error) {
    console.error("❌ Error updating quiz:", error);
    res.status(500).json({ error: "Error updating quiz" });
  }
});

// ✅ DELETE /api/quiz/:id - Delete a quiz (Protected)
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const deletedQuiz = await Quiz.findByIdAndDelete(req.params.id);

    if (!deletedQuiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    res.json({ message: "Quiz deleted successfully" });
  } catch (error) {
    console.error("❌ Error deleting quiz:", error);
    res.status(500).json({ error: "Error deleting quiz" });
  }
});


// ✅ GET /api/quiz - Get all quizzes
router.get("/", async (req, res) => {
  try {
    const quizzes = await Quiz.find();
    res.json(quizzes);
  } catch (error) {
    console.error("❌ Error fetching quizzes:", error);
    res.status(500).json({ error: "Error fetching quizzes" });
  }
});

// ✅ GET /api/quiz/:id - Get quiz by ID
router.get("/:id", async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) return res.status(404).json({ error: "Quiz not found" });
    res.json(quiz);
  } catch (error) {
    console.error("Error fetching quiz by ID", error);
    res.status(500).json({ error: "Error fetching quiz by ID" });
  }
});

// ✅ POST /api/quiz/submit/:id - Submit quiz answers and calculate score + correct answers
router.post("/submit/:id", async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) return res.status(404).json({ error: "Quiz not found" });

    const userAnswers = req.body.answers; // array of user's selected answers

    let score = 0;
    const results = [];

    quiz.questions.forEach((question, index) => {
      const isCorrect = userAnswers[index] === question.correctAnswer;
      if (isCorrect) score++;

      results.push({
        questionText: question.questionText,
        selectedAnswer: userAnswers[index],
        correctAnswer: question.correctAnswer,
        isCorrect,
      });
    });

    res.json({
      total: quiz.questions.length,
      score,
      results, // 👈 includes correct answers and user selections
    });

  } catch (err) {
    console.error("❌ Error submitting quiz:", err);
    res.status(500).json({ error: "Error submitting quiz" });
  }
});


module.exports = router;
