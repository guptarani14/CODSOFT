import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const QuizList = () => {
  const [quizzes, setQuizzes] = useState([]);

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/quiz');
        setQuizzes(res.data);
      } catch (err) {
        console.error('❌ Error fetching quizzes:', err);
      }
    };

    fetchQuizzes();
  }, []);

  // 🌈 Styling
  const pageStyle = {
    background: "linear-gradient(to right, #f3e5f5, #e0f7fa)",
    minHeight: "100vh",
    padding: "40px 20px",
    fontFamily: "Segoe UI, sans-serif",
  };

  const headingStyle = {
    textAlign: "center",
    color: "#4a148c",
    fontSize: "30px",
    marginBottom: "30px",
    fontWeight: "bold",
  };

  const quizCard = {
    background: "#ffffff",
    borderRadius: "10px",
    padding: "20px",
    marginBottom: "20px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  };

  const titleText = {
    fontSize: "18px",
    color: "#1a237e",
    fontWeight: "600",
  };

  const buttonStyle = {
    padding: "10px 16px",
    backgroundColor: "#00b894",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    fontSize: "15px",
    fontWeight: "bold",
    textDecoration: "none",
    transition: "0.3s",
  };

  const noQuizText = {
    textAlign: "center",
    fontSize: "18px",
    color: "#555",
    marginTop: "20px",
  };

  return (
    <div style={pageStyle}>
      <h2 style={headingStyle}>📋 All Available Quizzes</h2>

      {quizzes.length === 0 ? (
        <p style={noQuizText}>No quizzes available yet.</p>
      ) : (
        quizzes.map((quiz) => (
          <div key={quiz._id} style={quizCard}>
            <div style={titleText}>
              {quiz.title} &nbsp; 📎 ({quiz.questions.length} questions)
            </div>
            <Link to={`/quiz/${quiz._id}`} style={buttonStyle}>
              🎯 Take Quiz
            </Link>
          </div>
        ))
      )}
    </div>
  );
};

export default QuizList;
