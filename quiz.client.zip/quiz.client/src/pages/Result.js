import React from 'react';

function Result() {
  return <h2>Quiz Result Page 🏆</h2>;
}

export default Result;
