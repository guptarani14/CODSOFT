import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/auth/register', formData);
      alert('User registered successfully!');
    } catch (err) {
      alert('Registration failed!');
      console.error(err);
    }
  };

  const pageStyle = {
    height: '100vh',
    margin: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: 'linear-gradient(135deg, #fffacd, #fefbd8)', // light yellow
    fontFamily: 'Segoe UI, sans-serif',
  };

  const cardStyle = {
    background: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
    padding: '25px 30px',
    width: '320px', // slightly wider
    textAlign: 'center',
  };

  const inputStyle = {
    width: '100%',
    padding: '14px', // Increased padding
    margin: '10px 0',
    border: '1px solid #ccc',
    borderRadius: '8px',
    fontSize: '16px', // Bigger text
  };

  const buttonStyle = {
    width: '100%',
    padding: '12px',
    borderRadius: '6px',
    backgroundColor: '#f4c430',
    border: 'none',
    color: '#333',
    fontWeight: 'bold',
    fontSize: '16px',
    marginTop: '15px',
    cursor: 'pointer',
  };

  const headingStyle = {
    fontSize: '22px',
    marginBottom: '20px',
    color: '#444',
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h2 style={headingStyle}>Register</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="username"
            placeholder="Username"
            style={{ ...inputStyle, backgroundColor: '#fff9e6' }} // optional subtle highlight
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            style={inputStyle}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            style={inputStyle}
            onChange={handleChange}
            required
          />
          <button type="submit" style={buttonStyle}>Sign Up</button>
        </form>
      </div>
    </div>
  );
};

export default Register;
