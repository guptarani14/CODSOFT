import React from 'react';

const Home = () => {
  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    background: 'linear-gradient(135deg, #ff9a9e, #fad0c4, #fad0c4, #fbc2eb, #a18cd1)',
    fontFamily: 'Segoe UI, sans-serif',
  };

  const textStyle = {
    fontSize: '3rem',
    fontWeight: 'bold',
    color: '#ffffff',
    textShadow: '2px 2px 5px rgba(0,0,0,0.3)',
    textAlign: 'center',
    padding: '0 20px',
  };

  return (
    <div style={containerStyle}>
      <h1 style={textStyle}>🎉 Welcome to the Quiz App! 🎉</h1>
    </div>
  );
};

export default Home;
