import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-4">
      <Link className="navbar-brand" to="/">Quiz Maker</Link>
      <div className="navbar-nav">
        <Link className="nav-link" to="/">Home</Link>
        <Link className="nav-link" to="/register">Register</Link>
        <Link className="nav-link" to="/login">Login</Link>
        <Link className="nav-link" to="/create">Create Quiz</Link>
        <Link className="nav-link" to="/quizzes">Quizzes</Link>
      </div>
    </nav>
  );
};

export default Navbar;
